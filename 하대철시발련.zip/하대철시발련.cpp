#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;
queue<int>p1;
queue<int>p2;
int main() {
	int test; cin >> test;
	while (test--) {
		int num; cin >> num;
		int cnt = 0;
		int cnt1 = 0;
		for (int i = 0; i < num; i++) {
			int k; cin >> k;
			p1.push(k);
		}
		for (int i = 0; i < num; i++) {
			int k; cin >> k;
			p2.push(k);
		}
		for (int i = 0; i < num; i++) {
			int x = p1.front();
			int y = p2.front();
			p1.pop(); p2.pop();
			if (x > y)cnt++;
			else if (x < y)cnt1++;
		}
		if (cnt > cnt1)cout << "1" << "\n";
		else if (cnt < cnt1)cout << "2" << "\n";
		else cout << "0" << "\n";
	}
}